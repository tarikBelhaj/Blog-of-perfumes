---
layout: post
title: "Welcome to the Blog"
date: 2024-05-28
categories: [perfume]
---

Welcome to the Blog of Perfumes! This is your first post. Stay tuned for more!

